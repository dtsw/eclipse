package com.ofrick;

import org.apache.axiom.om.OMElement;

public interface SerializableOMElement extends OMElement {

}
