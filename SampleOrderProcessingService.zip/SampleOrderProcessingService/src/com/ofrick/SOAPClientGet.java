package com.ofrick;

import javax.xml.soap.*;

public class SOAPClientGet {


    private static String escalationScheme;
    private static String alertDefName;
    private static String resourceName;
    private static String alertId;
    private static String timeStamp;
    private static String message;

    public static void main(String args[]) throws Exception {


        String debugArgs = "EAI___Test___blaaa___12345___201405161307___This is a message";
        // split command line arguments
        //String[] params = args[0].split("___");
        String[] params = debugArgs.split("___");
        escalationScheme = params[0];
        alertDefName = params[1];
        resourceName = params[2];
        alertId = params[3];
        timeStamp = params[4];
        message = alertDefName + "," + resourceName;

        // Create SOAP Connection
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();

        // Send SOAP Message to SOAP Server
        //String url = "http://h0345.swi.srse.net/SOAPListener/I3SOAPISAPIU.DLL/#alarm";
        String url = "http://localhost:8080/axis2/services/SampleTelalertService/GetTelalertByEscalation";
        SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(), url);

        // print SOAP Response
        System.out.print("Response SOAP Message:");
        soapResponse.writeTo(System.out);

        soapConnection.close();


    }
    private static SOAPMessage createSOAPRequest() throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://h0345.swi.srse.net/SOAPListener/I3SOAPISAPIU.DLL#alarm";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("tam", serverURI);

        /*
        Constructed SOAP Request Message:
        <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:example="http://ws.cdyne.com/">
            <SOAP-ENV:Header/>
            <SOAP-ENV:Body>
                <example:VerifyEmail>
                    <example:email>mutantninja@gmail.com</example:email>
                    <example:LicenseKey>123</example:LicenseKey>

        </example:VerifyEmail>
    </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
 */

// SOAP Body
SOAPBody soapBody = envelope.getBody();
SOAPElement soapGetTelalert = soapBody.addChildElement("telalert", "tam");
SOAPElement soapBodyElem = soapGetTelalert.addChildElement("escalation", "tam");
soapBodyElem.addTextNode("TEST");

MimeHeaders headers = soapMessage.getMimeHeaders();
//headers.addHeader("SOAPAction", serverURI);
headers.addHeader("SOAPAction", "http://localhost:8080/axis2/services/SampleTelalertService/GetTelalertByEscalation");
soapMessage.saveChanges();

/* Print the request message */
System.out.print("Request SOAP Message:");
soapMessage.writeTo(System.out);
System.out.println();

return soapMessage;
}

}

