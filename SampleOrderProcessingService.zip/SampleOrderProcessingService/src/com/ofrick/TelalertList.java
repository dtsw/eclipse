package com.ofrick;

import java.util.concurrent.ConcurrentLinkedQueue;

public class TelalertList extends ConcurrentLinkedQueue<TelalertEntry> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5497325971924111761L;

}
