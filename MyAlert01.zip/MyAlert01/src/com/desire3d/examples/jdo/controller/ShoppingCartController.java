/**
 * 
 */
package com.desire3d.examples.jdo.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.desire3d.examples.jdo.ds.ShoppingCartDS;
import com.desire3d.examples.jdo.model.CartItem;
import com.desire3d.examples.jdo.model.ShoppingCart;
import com.desire3d.examples.jdo.repository.ShoppingCartRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author mahesh
 *
 */
@RestController
@RequestMapping(value = "/ShoppingCart")
public class ShoppingCartController {

	private final ShoppingCartDS service;
	private final ShoppingCartRepository repository;

	public ShoppingCartController(ShoppingCartDS service, ShoppingCartRepository repository) {
		super();
		this.service = service;
		this.repository = repository;
	}

	@RequestMapping(value="/addItem", method=RequestMethod.POST)
	public Mono<ShoppingCart> addItem(@RequestBody CartItem item) {
		return service.addItem(item);
	}

	@RequestMapping(value="/save", method=RequestMethod.POST)
	public Mono<ShoppingCart> save(@RequestBody ShoppingCart shoppingCart) {
		return repository.save(shoppingCart);
	}

	@RequestMapping(value="/update", method=RequestMethod.POST)
	public Mono<ShoppingCart> update(@RequestBody ShoppingCart shoppingCart) {
		return repository.update(shoppingCart);
	}

	@RequestMapping(value="/findAll", method=RequestMethod.GET)
	public Flux<ShoppingCart> findAll() {
		return repository.findAll();
	}

	@RequestMapping(value="/findById/{id}", method=RequestMethod.GET)
	public Mono<ShoppingCart> findById(@PathVariable String id) {
		return repository.findById(id);
	}

	@RequestMapping(value="/findByCustomerId/{customerId}", method=RequestMethod.GET)
	public Flux<ShoppingCart> findByCustomerId(@PathVariable String customerId) {
		return repository.findByCustomerId(customerId);
	}

	@RequestMapping(value="/removeItem/{cartItemId}", method=RequestMethod.DELETE)
	public void removeItem(@PathVariable Long cartItemId) {
		repository.removeItem(cartItemId);
	}

	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	public void delete(@PathVariable String id) {
		repository.delete(id);
	}
}