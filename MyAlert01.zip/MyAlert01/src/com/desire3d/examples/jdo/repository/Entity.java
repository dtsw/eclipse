package com.desire3d.examples.jdo.repository;

public abstract class Entity {
	public abstract Long getId();
}
