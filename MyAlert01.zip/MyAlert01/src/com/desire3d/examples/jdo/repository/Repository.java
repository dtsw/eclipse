package com.desire3d.examples.jdo.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Repository<T extends Entity> {
	
	public Map<Long, T> convertToMap(List<T> entities) {
		Map<Long, T> result = new HashMap<Long, T>();
		
		for (T entity : entities) {
			result.put(entity.getId(), entity);
		}
		
		return result;
}
	
	protected T getSingleOrDefault(List<T> entities) {
		if (entities.size() == 1) {
			return entities.get(0);
		} else {
			return null;
		}
}
}
