package com.desire3d.examples.jdo.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RepositoryHelper {
	
	public static Map convertToMap(List entities) {
		Map result = new HashMap();
		
		for (Object entity : entities) {
			//result.put(entity.getId(), entity);
		}
		
		return result;
}
	
	public static Object getSingleOrDefault(List entities) {
		if (entities.size() == 1) {
			return entities.get(0);
		} else {
			return null;
		}
}
}
