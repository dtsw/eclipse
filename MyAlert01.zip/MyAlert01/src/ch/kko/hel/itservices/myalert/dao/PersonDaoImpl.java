package ch.kko.hel.itservices.myalert.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.Extent;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ch.kko.hel.itservices.myalert.MyAlertPersistenceManager;
import ch.kko.hel.itservices.myalert.entity.Person;
import ch.kko.hel.itservices.myalert.mapper.PersonMapper;

@Repository
public class PersonDaoImpl implements PersonDao {

	@Autowired
	private PersonMapper personMapper;

	@Autowired
	ServletContext context;

	@Override
	public void insert(Person person) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Person> getAll() {
        PersistenceManagerFactory pmf = (PersistenceManagerFactory) context.getAttribute("pmf");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx=pm.currentTransaction();
        tx.begin();
        Extent<Person> e2 = pm.getExtent(Person.class, true);
		List<Person> persons = new ArrayList<Person>();
		Iterator<Person> iter2 = e2.iterator();
		while (iter2.hasNext()) {
			Object obj = iter2.next();
			Person g = (Person) obj;
        	persons.add(g);
		}
		tx.commit();
		return persons;
	}

	@Override
	public Person getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Person person) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(Person person) {
		// TODO Auto-generated method stub

	}

}
