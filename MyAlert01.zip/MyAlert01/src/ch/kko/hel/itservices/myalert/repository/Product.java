package ch.kko.hel.itservices.myalert.repository;

public class Product {

}
