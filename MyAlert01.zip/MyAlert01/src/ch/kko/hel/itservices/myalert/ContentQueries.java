package ch.kko.hel.itservices.myalert;

import java.util.Iterator;
import java.util.Collection;
import javax.jdo.*;

import ch.kko.hel.itservices.myalert.entity.*;

public class ContentQueries {
    
    public static Group getGroupByName(PersistenceManager pm,
            String groupName) {
        Extent groupExtent = pm.getExtent(Group.class,
                false);
        Query query = pm.newQuery(groupExtent, "name == groupName");
        query.declareParameters("String groupName");
        Collection result = (Collection) query.execute(groupName);
        Iterator iter = result.iterator();
        Group group = (Group) (iter.hasNext() ? iter.next() : null);
        query.close(result);
        return group;
    }

    public static Group getGroupById(PersistenceManager pm,
            Integer id) {
        Extent groupExtent = pm.getExtent(Group.class,
                false);
        Query query = pm.newQuery(groupExtent, "id == p_id");
        query.declareParameters("Integer p_id");
        Collection result = (Collection) query.execute(id);
        Iterator iter = result.iterator();
        Group group = (Group) (iter.hasNext() ? iter.next() : null);
        query.close(result);
        return group;
    }

    public static void getGroups(PersistenceManager pm) {
        Extent groupExtent = pm.getExtent(Group.class,
                false);
        Iterator iter = groupExtent.iterator();
        while (iter.hasNext()) {
            Group g = (Group) iter.next();
            //LOGGER.debug(g.toString());

            for (Subscriber s : g.getSubscribers()) {
                //LOGGER.debug(s.toString());
                if (s instanceof Person) {
                    Person p = (Person) s;
                    for (Device d : p.getDevices()) {
                        //LOGGER.debug(d.toString());
                    }
                }
            }
        }
    }

    public static Person getPersonByUserName(PersistenceManager pm,
            String name) {
        Extent personExtent = pm.getExtent(Person.class,
                false);
        Query query = pm.newQuery(personExtent, "username == name");
        query.declareParameters("String name");
        Collection result = (Collection) query.execute(name);
        Iterator iter = result.iterator();
        Person person = (Person) (iter.hasNext() ? iter.next() : null);
        query.close(result);
        return person;
    }

    public static Schedule getScheduleByName(PersistenceManager pm, String scheduleName) {
        Extent scheduleExtent = pm.getExtent(Schedule.class,
                false);
        Query query = pm.newQuery(scheduleExtent, "name == scheduleName");
        query.declareParameters("String scheduleName");
        Collection result = (Collection) query.execute(scheduleName);
        Iterator iter = result.iterator();
        Schedule schedule = (Schedule) (iter.hasNext() ? iter.next() : null);
        query.close(result);
        return schedule;
    }

    public static Device getDeviceByAddress(PersistenceManager pm, String deviceAddress) {
        Extent deviceExtent = pm.getExtent(Device.class,
                false);
        Query query = pm.newQuery(deviceExtent, "address == deviceAddress");
        query.declareParameters("String deviceAddress");
        Collection result = (Collection) query.execute(deviceAddress);
        Iterator iter = result.iterator();
        Device device = (Device) (iter.hasNext() ? iter.next() : null);
        query.close(result);
        return device;
    }

}
