package ch.kko.hel.itservices.myalert.dto;

public class PersonGroupDto {
	
	private PersonDto personDto;
	private GroupDto groupDto;
	
	public PersonDto getPersonDto() {
		return personDto;
	}
	public void setPersonDto(PersonDto personDto) {
		this.personDto = personDto;
	}
	public GroupDto getGroupDto() {
		return groupDto;
	}
	public void setGroupDto(GroupDto groupDto) {
		this.groupDto = groupDto;
	}

	
}
