package ch.kko.hel.itservices.myalert;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.springframework.stereotype.Component;

@Component
public class MyAlertPersistenceManager extends HttpServlet {

	private PersistenceManagerFactory pmf;
	private PersistenceManager pm;
	
	public MyAlertPersistenceManager() {
		System.out.println("Created MyAlertPersistenceManager");
		System.out.println(this);
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		pmf = JDOHelper.getPersistenceManagerFactory("Tutorial");
		System.out.println("Created pmf");
		config.getServletContext().setAttribute("pmf", pmf);
	}

	public PersistenceManager getPm() {
		return pm;
	}

	@Override
	public void destroy() {
		pm = pmf.getPersistenceManager();
		if ( ! pm.isClosed() ) {
			pm.close();
			System.out.println("Closing pm");
		}
		if ( ! pmf.isClosed() ) {
			pmf.close();			
		}
	}

	
}
