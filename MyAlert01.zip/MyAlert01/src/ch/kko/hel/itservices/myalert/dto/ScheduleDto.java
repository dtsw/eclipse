package ch.kko.hel.itservices.myalert.dto;

public class ScheduleDto {
	
	private Integer id;
	private String name;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

}
