package ch.kko.hel.itservices.myalert.service;

import java.util.List;

import ch.kko.hel.itservices.myalert.dto.GroupDto;

public interface GroupService {
	
	public GroupDto findByName(String name);

	public void create(GroupDto groupDto) ;
	public List<GroupDto> findAll();
	public GroupDto findById(Integer id);
	public void remove(Integer id);
	public void edit(GroupDto groupDto);
	
}
