package ch.kko.hel.itservices.myalert.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.springframework.stereotype.Repository;

import ch.kko.hel.itservices.myalert.PMFConfig;
import ch.kko.hel.itservices.myalert.entity.Device;

@Repository
public class DeviceRepositoryImpl implements DeviceRepository {

	@Override
	public Device save(Device device) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		pm.makePersistent(device);
		return device;
	}

	@Override
	public Device update(Device device) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		pm.makePersistent(device);
		return device;
	}

	@Override
	public List<Device> findAll() {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Query query = pm.newQuery(Device.class);
		List<Device> devices = (List<Device>) query.execute();
		return devices;
	}

	@Override
	public Device findById(Long deviceId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Device device = (Device) pm.getObjectById(Device.class, deviceId);
		return device;
	}

	@Override
	public void delete(Long deviceId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Device device = (Device) pm.getObjectById(Device.class, deviceId);
		pm.deletePersistent(device);
	}
	
}
