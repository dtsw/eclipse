package ch.kko.hel.itservices.myalert.mapper;

import org.springframework.stereotype.Component;

import ch.kko.hel.itservices.myalert.dto.DeviceDto;
import ch.kko.hel.itservices.myalert.entity.Device;

@Component
public class DeviceMapper {
	public Device mapDtoToEntity(DeviceDto deviceDto) {
		Device device = new Device();
		if(null != deviceDto.getId()) device.setId(deviceDto.getId());
		if(null != deviceDto.getType()) device.setType(deviceDto.getType());
		if(null != deviceDto.getAddress()) device.setAddress(deviceDto.getAddress());
		return device;
	}
	
	public DeviceDto mapEntityToDto(Device device) {
		DeviceDto DeviceDto = new DeviceDto();
		if(null != device.getId()) DeviceDto.setId(device.getId());
		if(null != device.getType()) DeviceDto.setType(device.getType());
		if(null != device.getAddress()) DeviceDto.setAddress(device.getAddress());
		return DeviceDto;
	}
}
