package ch.kko.hel.itservices.myalert.repository;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Person;
import ch.kko.hel.itservices.myalert.entity.Subscriber;

public interface PersonRepository {

	public Person save(Person person);

	public Person update(Person person);

	public void delete(Long personId);

	public List<Person> findAll();

	public Person findById(Long personId);	
	
	public void addDevice(Long personId, Long deviceId);
	
	public void removeDevice(Long personId, Long deviceId);

}
