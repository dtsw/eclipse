package ch.kko.hel.itservices.myalert.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.desire3d.examples.jdo.model.CartItem;
import com.desire3d.examples.jdo.model.ShoppingCart;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.kko.hel.itservices.myalert.dto.DevicePersonDto;
import ch.kko.hel.itservices.myalert.entity.Person;
import ch.kko.hel.itservices.myalert.entity.Subscriber;
import ch.kko.hel.itservices.myalert.repository.PersonRepository;

@RestController
@RequestMapping(value="/person")
public class NewPersonController {

	@Autowired
	private PersonRepository repository;
	
	@RequestMapping(value="/findAll", method=RequestMethod.GET)
	public List<Person> findAll() {
		return repository.findAll();
	}

	@RequestMapping(value="/findById/{id}", method=RequestMethod.GET)
	public Person findById(@PathVariable Long id) {
		return repository.findById(id);
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public Person save(@RequestBody Person person) {
		return repository.save(person);
	}

	@RequestMapping(value="/addDevice", method=RequestMethod.POST)
	@ResponseBody
	public Subscriber addItem(@RequestBody DevicePersonDto item) {
		Long personId = Long.valueOf(item.getPersonDto().getId());
		Long deviceId = Long.valueOf(item.getDeviceDto().getId());
		repository.addDevice(personId, deviceId);
		return null;
	}
	
	@RequestMapping(value="/removeDevice", method=RequestMethod.POST)
	@ResponseBody
	public Subscriber removeItem(@RequestBody DevicePersonDto item) {
		Long personId = Long.valueOf(item.getPersonDto().getId());
		Long deviceId = Long.valueOf(item.getDeviceDto().getId());
		repository.removeDevice(personId, deviceId);
		return null;
	}
}
