package ch.kko.hel.itservices.myalert.dto;

public class DeviceGroupDto {
	
	private DeviceDto deviceDto;
	private GroupDto groupDto;
	
	public DeviceDto getDeviceDto() {
		return deviceDto;
	}
	public void setDeviceDto(DeviceDto deviceDto) {
		this.deviceDto = deviceDto;
	}
	public GroupDto getGroupDto() {
		return groupDto;
	}
	public void setGroupDto(GroupDto groupDto) {
		this.groupDto = groupDto;
	}

	
}
