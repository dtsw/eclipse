package ch.kko.hel.itservices.myalert.service;

import java.util.List;

import ch.kko.hel.itservices.myalert.dto.PersonDto;

public interface PersonService {
	public List<PersonDto> findAll();
}
