package ch.kko.hel.itservices.myalert.dao;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Subscriber;

public interface SubscriberGroupDao {
	public List<Subscriber> getAll();
	public List<Subscriber> isPresent(Integer subscriberId, Integer groupId);
}
