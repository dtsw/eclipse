package ch.kko.hel.itservices.myalert.mapper;

import org.springframework.stereotype.Component;

import ch.kko.hel.itservices.myalert.dto.GroupDto;
import ch.kko.hel.itservices.myalert.entity.Group;

@Component
public class GroupMapper {
	public Group mapDtoToEntity(GroupDto groupDto) {
		Group group = new Group();
		if(null != groupDto.getId()) group.setId(groupDto.getId());
		if(null != groupDto.getName()) group.setName(groupDto.getName());
		if(null != groupDto.getDescription()) group.setDescription(groupDto.getDescription());
		return group;
	}
	
	public GroupDto mapEntityToDto(Group group) {
		GroupDto GroupDto = new GroupDto();
		if(null != group.getId()) GroupDto.setId(group.getId());
		if(null != group.getName()) GroupDto.setName(group.getName());
		if(null != group.getDescription()) GroupDto.setDescription(group.getDescription());
		return GroupDto;
	}
}
