package ch.kko.hel.itservices.myalert.entity;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

/**
 * Definition of a Subscriber
 * Represents a subscriber, and contains the key aspects of the item.
 */
@PersistenceCapable
public class Subscriber
{
    @PrimaryKey
    @Persistent(valueStrategy=IdGeneratorStrategy.NATIVE)
    protected Integer id;

    protected String type;
    
    public Subscriber(String type)
    {
    	this.type = type;
    }

    public void setId(Integer id)
    {
    	this.id = id;
    }
    
    public Integer getId()
    {
        return id;
    }

    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String toString()
    {
        return "Subscriber : " + id + " Type: " + type;
    }
}