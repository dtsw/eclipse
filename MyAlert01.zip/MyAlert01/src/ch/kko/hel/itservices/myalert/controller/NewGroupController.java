package ch.kko.hel.itservices.myalert.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.desire3d.examples.jdo.model.CartItem;
import com.desire3d.examples.jdo.model.ShoppingCart;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.kko.hel.itservices.myalert.dto.DeviceGroupDto;
import ch.kko.hel.itservices.myalert.dto.GroupDto;
import ch.kko.hel.itservices.myalert.dto.PersonDto;
import ch.kko.hel.itservices.myalert.dto.PersonGroupDto;
import ch.kko.hel.itservices.myalert.dto.SubscriberDto;
import ch.kko.hel.itservices.myalert.dto.SubscriberGroupDto;
import ch.kko.hel.itservices.myalert.entity.Group;
import ch.kko.hel.itservices.myalert.entity.Person;
import ch.kko.hel.itservices.myalert.entity.Subscriber;
import ch.kko.hel.itservices.myalert.repository.GroupRepository;
import ch.kko.hel.itservices.myalert.repository.PersonRepository;

@RestController
@RequestMapping(value="/group")
public class NewGroupController {

	@Autowired
	private GroupRepository repository;
	
	@RequestMapping(value="/findAll", method=RequestMethod.GET)
	public List<Group> findAll() {
		return repository.findAll();
	}

	@RequestMapping(value="/findById/{id}", method=RequestMethod.GET)
	public Group findById(@PathVariable Long id) {
		return repository.findById(id);
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public Group save(@RequestBody Group group) {
		return repository.save(group);
	}

	@RequestMapping(value="/update", method=RequestMethod.POST)
	public Group update(@RequestBody Group group) {
		return repository.update(group);
	}

	@RequestMapping(value="/delete/{id}", method=RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id) {
		repository.delete(id);
	}
	
	@RequestMapping(value="/addPerson", method=RequestMethod.POST)
	@ResponseBody
	public Subscriber addItem(@RequestBody PersonGroupDto item) {
		Long groupId = Long.valueOf(item.getGroupDto().getId());
		Long personId = Long.valueOf(item.getPersonDto().getId());
		Subscriber g = repository.addPerson(groupId, personId);
		return g;
	}
	
	@RequestMapping(value="/removePerson", method=RequestMethod.POST)
	@ResponseBody
	public Subscriber removeItem(@RequestBody PersonGroupDto item) {
		Long groupId = Long.valueOf(item.getGroupDto().getId());
		Long personId = Long.valueOf(item.getPersonDto().getId());
		Subscriber g = repository.removePerson(groupId, personId);
		return g;
	}

	@RequestMapping(value="/addDevice", method=RequestMethod.POST)
	@ResponseBody
	public Subscriber addItem(@RequestBody DeviceGroupDto item) {
		Long groupId = Long.valueOf(item.getGroupDto().getId());
		Long deviceId = Long.valueOf(item.getDeviceDto().getId());
		Subscriber g = repository.addDevice(groupId, deviceId);
		return g;
	}
	
	@RequestMapping(value="/removeDevice", method=RequestMethod.POST)
	@ResponseBody
	public Subscriber removeItem(@RequestBody DeviceGroupDto item) {
		Long groupId = Long.valueOf(item.getGroupDto().getId());
		Long deviceId = Long.valueOf(item.getDeviceDto().getId());
		Subscriber g = repository.removeDevice(groupId, deviceId);
		return g;
	}
}
