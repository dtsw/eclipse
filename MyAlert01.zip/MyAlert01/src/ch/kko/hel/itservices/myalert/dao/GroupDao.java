package ch.kko.hel.itservices.myalert.dao;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Group;

public interface GroupDao {

	public void insert(Group group);
	public List <Group>  getAll();
	public Group getById(Integer id);
	public Group getByName(String name);
	public void delete(Group group) ;
	public void update(Group group);
	
}
