package ch.kko.hel.itservices.myalert.dto;

public class DevicePersonDto {
	
	private DeviceDto deviceDto;
	private PersonDto personDto;
	
	public DeviceDto getDeviceDto() {
		return deviceDto;
	}
	public void setDeviceDto(DeviceDto deviceDto) {
		this.deviceDto = deviceDto;
	}
	public PersonDto getPersonDto() {
		return personDto;
	}
	public void setPersonDto(PersonDto personDto) {
		this.personDto = personDto;
	}

}
