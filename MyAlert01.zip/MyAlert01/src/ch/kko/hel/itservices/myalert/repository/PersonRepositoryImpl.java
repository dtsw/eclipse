package ch.kko.hel.itservices.myalert.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.desire3d.examples.jdo.model.Product;
import com.desire3d.examples.jdo.model.ShoppingCart;

import ch.kko.hel.itservices.myalert.PMFConfig;
import ch.kko.hel.itservices.myalert.entity.Device;
import ch.kko.hel.itservices.myalert.entity.Person;
import reactor.core.publisher.Mono;

@Repository
public class PersonRepositoryImpl implements PersonRepository {

	@Override
	public Person save(Person person) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		pm.makePersistent(person);
		return person;
	}

	@Override
	public Person update(Person person) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Person personBefore = pm.getObjectById(Person.class, person.getId());
		if (person.getFirstname() != null)
			personBefore.setFirstname(person.getFirstname());
		if (person.getLastname() != null)
			personBefore.setLastname(person.getLastname());
		if (person.getUsername() != null)
			personBefore.setUsername(person.getUsername());
		pm.makePersistent(personBefore);
		return personBefore;
	}

	@Override
	public List<Person> findAll() {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Query query = pm.newQuery(Person.class);
		List<Person> persons = (List<Person>) query.execute();
		return persons;
	}

	@Override
	public Person findById(Long personId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Person person = (Person) pm.getObjectById(Person.class, personId);
		return person;
	}

	@Override
	public void delete(Long personId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Person person = (Person) pm.getObjectById(Person.class, personId);
		person.getDevices().clear();
		pm.deletePersistent(person);
	}

	@Override
	public void addDevice(Long personId, Long deviceId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Person person = (Person) pm.getObjectById(Person.class, personId);
		Device device = (Device) pm.getObjectById(Device.class, deviceId);
		person.getDevices().add(device);
		pm.makePersistent(person);
	}

	@Override
	public void removeDevice(Long personId, Long deviceId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Person person = (Person) pm.getObjectById(Person.class, personId);
		Device device = (Device) pm.getObjectById(Device.class, deviceId);
		person.getDevices().remove(device);
		pm.makePersistent(person);		
	}
	
}
