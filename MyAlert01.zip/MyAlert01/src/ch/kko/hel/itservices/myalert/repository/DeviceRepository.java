package ch.kko.hel.itservices.myalert.repository;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Device;
import ch.kko.hel.itservices.myalert.entity.Subscriber;

public interface DeviceRepository {

	public Device save(Device device);

	public Device update(Device device);

	public void delete(Long deviceId);

	public List<Device> findAll();

	public Device findById(Long deviceId);
	
}
