package ch.kko.hel.itservices.myalert;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;
import javax.servlet.*;
import javax.servlet.http.*;

import ch.kko.hel.itservices.myalert.entity.Device;
import ch.kko.hel.itservices.myalert.entity.Person;
import ch.kko.hel.itservices.myalert.entity.Subscriber;

import java.io.*;
import java.util.Iterator;

public class Hello extends HttpServlet {
	
	PersistenceManagerFactory pmf = null;
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init(); 
		// Create a PersistenceManagerFactory for this datastore

//		PersistenceUnitMetaData pumd = new PersistenceUnitMetaData("dynamic-unit", "RESOURCE_LOCAL", null);
//		pumd.addClassName("org.datanucleus.samples.jdo.tutorial.Subscriber");		
//		pumd.addProperty("javax.jdo.PersistenceManagerFactoryClass", "org.datanucleus.api.jdo.JDOPersistenceManagerFactory");
//		pumd.addProperty("javax.jdo.option.ConnectionURL","jdbc:derby://localhost:1527/nucleus");
//		pumd.addProperty("javax.jdo.option.ConnectionDriverName","org.apache.derby.jdbc.ClientDriver");
//		pumd.addProperty("javax.jdo.option.ConnectionUserName","nucleus");
//		pumd.addProperty("javax.jdo.option.ConnectionPassword","nucleus");
//		pumd.addProperty("datanucleus.schema.autoCreateAll","true");		
//		pmf = new JDOPersistenceManagerFactory(pumd, null);

//		Properties properties = new Properties();
//		properties.setProperty("javax.jdo.PersistenceManagerFactoryClass", "org.datanucleus.api.jdo.JDOPersistenceManagerFactory");
//		properties.setProperty("javax.jdo.option.ConnectionURL","jdbc:derby://localhost:1527/nucleus");
//		properties.setProperty("javax.jdo.option.ConnectionDriverName","org.apache.derby.jdbc.ClientDriver");
//		properties.setProperty("javax.jdo.option.ConnectionUserName","nucleus");
//		properties.setProperty("javax.jdo.option.ConnectionPassword","nucleus");
//		properties.setProperty("javax.jdo.option.Mapping","derby");
//        pmf = JDOHelper.getPersistenceManagerFactory(properties);
		pmf = JDOHelper.getPersistenceManagerFactory("Tutorial");
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = request.getParameter("user");
		
		if (request.getParameter("user") == null) {
			user = "world";
		}
		
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx=pm.currentTransaction();
        tx.begin();
        Person oliver = new Person("Oliver", "Frick", "HKJHW");
        pm.makePersistent(oliver);
        tx.commit();
        
		response.setContentType("text/html");
        
        PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<h1>Hello, " + user + "!</h1>");
		try
        {
            tx.begin();
            System.out.println("Retrieving Extent for Subscribers");
            Extent<Subscriber> e2 = pm.getExtent(Subscriber.class, true);
            Iterator<Subscriber> iter2 = e2.iterator();
            while (iter2.hasNext())
            {
                Object obj = iter2.next();
                out.println(">  " + obj);
                if ( obj instanceof Person ) { 
                	out.println("is a person");
                	Person pr = (Person) obj;
                	for ( Device dev : pr.getDevices() ) {
                		out.println(dev.getType() + ":" + dev.getAddress());
                	}
                }
                if ( obj instanceof Device ) out.println("is a device");
            }    
            tx.commit();
        }
        catch (Exception e)
        {
            System.out.println("Exception thrown during retrieval of Extent : " + e.getMessage());
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
		
		out.println("</body></html>");
	}
	
}
