package ch.kko.hel.itservices.myalert.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.kko.hel.itservices.myalert.dao.DeviceDao;
import ch.kko.hel.itservices.myalert.dto.DeviceDto;
import ch.kko.hel.itservices.myalert.dto.GroupDto;
import ch.kko.hel.itservices.myalert.entity.Device;
import ch.kko.hel.itservices.myalert.entity.Group;
import ch.kko.hel.itservices.myalert.mapper.DeviceMapper;
import ch.kko.hel.itservices.myalert.mapper.GroupMapper;

@Service
public class DeviceServiceImpl implements DeviceService {
	
	@Autowired
	private DeviceDao deviceDao;
	
	@Autowired
	private DeviceMapper deviceMapper;

	public List<DeviceDto> findAll() {
		
		List<Device> devices = deviceDao.getAll();
		List<DeviceDto> deviceDtos = new ArrayList<DeviceDto>();
		for(Device device : devices) {
			deviceDtos.add(deviceMapper.mapEntityToDto(device));
		}
		return deviceDtos;

	}

}
