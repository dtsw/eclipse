package ch.kko.hel.itservices.myalert.service;

import java.util.List;

import ch.kko.hel.itservices.myalert.dto.DeviceDto;

public interface DeviceService {
	public List<DeviceDto> findAll();
}
