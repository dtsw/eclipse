package ch.kko.hel.itservices.myalert.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "subscribertype", visible = true)
@JsonSubTypes({
    @Type(value = PersonDto.class, name = "person"),
    @Type(value = DeviceDto.class, name = "device") })
public class SubscriberDto {

}
