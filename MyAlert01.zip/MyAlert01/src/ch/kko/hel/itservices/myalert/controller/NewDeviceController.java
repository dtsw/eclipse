package ch.kko.hel.itservices.myalert.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.desire3d.examples.jdo.model.CartItem;
import com.desire3d.examples.jdo.model.ShoppingCart;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.kko.hel.itservices.myalert.entity.Device;
import ch.kko.hel.itservices.myalert.entity.Subscriber;
import ch.kko.hel.itservices.myalert.repository.DeviceRepository;

@RestController
@RequestMapping(value="/device")
public class NewDeviceController {

	@Autowired
	private DeviceRepository repository;
	
	@RequestMapping(value="/findAll", method=RequestMethod.GET)
	public List<Device> findAll() {
		return repository.findAll();
	}

	@RequestMapping(value="/findById/{id}", method=RequestMethod.GET)
	public Device findById(@PathVariable Long id) {
		return repository.findById(id);
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public Device save(@RequestBody Device device) {
		return repository.save(device);
	}

	@RequestMapping(value="/update", method=RequestMethod.POST)
	public Device update(@RequestBody Device device) {
		return repository.update(device);
	}

	@RequestMapping(value="/delete/{id}", method=RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id) {
		repository.delete(id);
	}
	
}
