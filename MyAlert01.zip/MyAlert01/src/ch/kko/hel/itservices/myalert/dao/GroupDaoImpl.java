package ch.kko.hel.itservices.myalert.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.jdo.Extent;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ch.kko.hel.itservices.myalert.ContentQueries;
import ch.kko.hel.itservices.myalert.MyAlertPersistenceManager;
import ch.kko.hel.itservices.myalert.entity.Group;
import ch.kko.hel.itservices.myalert.mapper.GroupMapper;

@Repository
public class GroupDaoImpl implements GroupDao {

	@Autowired
	private GroupMapper groupMapper;
	
	@Autowired
	ServletContext context;

	@Override
	public void insert(Group group) {
        PersistenceManagerFactory pmf = (PersistenceManagerFactory) context.getAttribute("pmf");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx=pm.currentTransaction();
        tx.begin();
        pm.makePersistent(group);
        tx.commit();
	}

	@Override
	public List<Group> getAll() {
        PersistenceManagerFactory pmf = (PersistenceManagerFactory) context.getAttribute("pmf");
        PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx=pm.currentTransaction();
        tx.begin();
        Extent<Group> e2 = pm.getExtent(Group.class, true);
		List<Group> groups = new ArrayList<Group>();
		Iterator<Group> iter2 = e2.iterator();
		while (iter2.hasNext()) {
			Object obj = iter2.next();
			Group g = (Group) obj;
        	groups.add(g);
		}
		tx.commit();
		return groups;
	}

	@Override
	public Group getById(Integer id) {
        PersistenceManagerFactory pmf = (PersistenceManagerFactory) context.getAttribute("pmf");
        PersistenceManager pm = pmf.getPersistenceManager();
		Group group = ContentQueries.getGroupById(pm, id);
		return group;
	}

	@Override
	public Group getByName(String name) {
        PersistenceManagerFactory pmf = (PersistenceManagerFactory) context.getAttribute("pmf");
        PersistenceManager pm = pmf.getPersistenceManager();
		Group group = ContentQueries.getGroupByName(pm, name);
		return group;
	}

	@Override
	public void delete(Group group) {
        PersistenceManagerFactory pmf = (PersistenceManagerFactory) context.getAttribute("pmf");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx=pm.currentTransaction();
        tx.begin();
		//Set subscribers = group.getSubscribers();
		pm.deletePersistent(group);
		tx.commit();
	}

	@Override
	public void update(Group group) {
		// TODO Auto-generated method stub

	}

}
