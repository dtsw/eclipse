package ch.kko.hel.itservices.myalert.service;

import java.util.List;

import ch.kko.hel.itservices.myalert.dto.SubscriberGroupDto;

public interface SubscriberGroupService {
	
	public SubscriberGroupDto findByName(String name);

	public void create(SubscriberGroupDto subscriberGroupDto) ;
	public List<SubscriberGroupDto> findAll();
	public SubscriberGroupDto findById(Integer id);
	public void remove(Integer id);
	public void edit(SubscriberGroupDto subscriberGroupDto);
	
}
