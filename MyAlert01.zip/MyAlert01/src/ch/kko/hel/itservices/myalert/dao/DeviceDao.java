package ch.kko.hel.itservices.myalert.dao;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Device;

public interface DeviceDao {

	public void insert(Device device);
	public List <Device>  getAll();
	public Device getById(Integer id);
	public void delete(Device device) ;
	public void update(Device device);
	
}
