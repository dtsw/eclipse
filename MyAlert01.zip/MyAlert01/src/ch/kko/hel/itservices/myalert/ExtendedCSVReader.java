package ch.kko.hel.itservices.myalert;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.*;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;

import ch.kko.hel.itservices.myalert.entity.*;

public class ExtendedCSVReader {

    public static void main(String[] args) throws Exception {

    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("Tutorial");
        String csvFile = "C:/D/alarmpoint_import.txt";

        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = "\t";
        String listSplitBy = ",";
        int counter1 = 0, counter2 = 0, counter3 = 0, counter4 = 0;

        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx=pm.currentTransaction();
        tx.begin();

        Schedule tag = new Schedule("WORKTIME");
        tag.getScheduledetails().add(new ScheduleDetail(Calendar.MONDAY, Calendar.FRIDAY, ScheduleDetail.FULL_DAY, 8, 18));
        pm.makePersistent(tag);

        Schedule immer = new Schedule("24X7");
        immer.getScheduledetails().add(new ScheduleDetail(Calendar.SUNDAY, Calendar.SATURDAY, ScheduleDetail.FULL_DAY));
        pm.makePersistent(immer);

        Schedule frueh = new Schedule("FRUEHSCHICHT");
        frueh.getScheduledetails().add(new ScheduleDetail(Calendar.MONDAY, Calendar.FRIDAY, ScheduleDetail.PART_DAY, 6, 18));
        pm.makePersistent(frueh);

        Schedule spaet = new Schedule("SPAETSCHICHT");
        spaet.getScheduledetails().add(new ScheduleDetail(Calendar.MONDAY, Calendar.FRIDAY, ScheduleDetail.PART_DAY, 14, 24));
        spaet.getScheduledetails().add(new ScheduleDetail(Calendar.SATURDAY, Calendar.SATURDAY, ScheduleDetail.PART_DAY, 0, 6));
        pm.makePersistent(spaet);

        Schedule wochenende = new Schedule("WOCHENENDE");
        wochenende.getScheduledetails().add(new ScheduleDetail(Calendar.SUNDAY, Calendar.SUNDAY, ScheduleDetail.FULL_DAY));
        wochenende.getScheduledetails().add(new ScheduleDetail(Calendar.SATURDAY, Calendar.SATURDAY, ScheduleDetail.PART_DAY, 6, 24));
        wochenende.getScheduledetails().add(new ScheduleDetail(Calendar.MONDAY, Calendar.MONDAY, ScheduleDetail.PART_DAY, 0, 6));
        pm.makePersistent(wochenende);

        Schedule sms = new Schedule("SMS 8-17 UHR");
        sms.getScheduledetails().add(new ScheduleDetail(Calendar.MONDAY, Calendar.FRIDAY, ScheduleDetail.PART_DAY, 6, 18));
        pm.makePersistent(sms);

        Schedule ora = new Schedule("ORACLE-S WEEKDAY SCHEDULE");
        ora.getScheduledetails().add(new ScheduleDetail(Calendar.MONDAY, Calendar.FRIDAY, ScheduleDetail.PART_DAY, 6, 19));
        pm.makePersistent(ora);
        tx.commit();

        try {

            String skip;

            br = new BufferedReader(new FileReader(csvFile));

            while ((line = br.readLine()) != null) {

            	System.out.println(line);
                StringTokenizer tokenizer = new StringTokenizer(line, cvsSplitBy);
                String group_name = tokenizer.nextToken();
                String group_schedule = tokenizer.nextToken();
                String recipientCat = tokenizer.nextToken();
                
                if (recipientCat.equals("PERSON")) {
                	System.out.println("Line with PERSON");
                    String user_name = tokenizer.nextToken();
                    String first_name = tokenizer.nextToken();
                    String last_name = tokenizer.nextToken();
                    String device_type = tokenizer.nextToken();
                    String device_address = tokenizer.nextToken();
                    String group_description = tokenizer.nextToken();
                    
                    System.out.println("group_name=" + group_name + " user_name=" + user_name + " first_name=" + first_name + " last_name=" + last_name + " device_type=" + device_type + " device_address=" + device_address);

                    tx.begin();
                    System.out.println("Searching Group");
                    Group group = ContentQueries.getGroupByName(pm, group_name);
                    if (group == null) {
                        System.out.println("Creating Group " + group_name);

                        group = new Group(group_name, group_description); // creates transient Group

                        StringTokenizer st = new StringTokenizer(group_schedule, listSplitBy);
                        while (st.hasMoreTokens()) {
                            Schedule schedule = ContentQueries.getScheduleByName(pm, st.nextToken());
                            if ( schedule != null ) {
                                System.out.println(schedule);
                                group.getSchedules().add(schedule);
                                //LOGGER.info("Schedule added to group.");
                            } else {
                                //LOGGER.warn("Could not add Schedule: Schedule not found!");
                            }
                        }
                        pm.makePersistent(group);
                    }
                    System.out.println("Searching Person");
                    Person person = ContentQueries.getPersonByUserName(pm, user_name);
                    if (person == null) {
                        System.out.println("Creating Person " + user_name);
                        counter1++;
                        person = new Person(first_name, last_name, user_name);
                        pm.makePersistent(person);
                    }
                    group.getSubscribers().add(person);
                    System.out.println("Searching Device");
                    Device device = ContentQueries.getDeviceByAddress(pm, device_address);
                    if (device == null) {
                        System.out.println("Creating Device" + device_address);
                        device = new Device(device_type, device_address);
                        pm.makePersistent(device);
                        person.getDevices().add(device);
                        //pm.makePersistent(person);
                    }
                    System.out.println(person);
                    System.out.println(device);
                    System.out.println(group);

                    tx.commit();
                    
                }
                
                if (recipientCat.equals("GROUP")) {
                	System.out.println("Line with GROUP");
                    String subGroup_name = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    String group_description = tokenizer.nextToken();
                    String groupOfGroup_memberSequence = tokenizer.nextToken();
                    String groupOfGroupUser_recipientCat = tokenizer.nextToken();
                    String user_name = tokenizer.nextToken();
                    String first_name = tokenizer.nextToken();
                    String last_name = tokenizer.nextToken();
                    String device_type = tokenizer.nextToken();
                    String device_address = tokenizer.nextToken();
                    String groupOfGroup_description = tokenizer.nextToken();

                    System.out.println(subGroup_name);
                    System.out.println(group_description);
                    System.out.println(groupOfGroup_memberSequence);
                    System.out.println(groupOfGroupUser_recipientCat);
                    System.out.println(user_name);
                    System.out.println(first_name);
                    System.out.println(last_name);
                    System.out.println(device_type);
                    System.out.println(device_address);
                    System.out.println(groupOfGroup_description);

                    System.out.println("group_name=" + group_name + " user_name=" + user_name + " first_name=" + first_name + " last_name=" + last_name + " device_type=" + device_type + " device_address=" + device_address);

                    tx.begin();
                    System.out.println("Searching Group");
                    Group group = ContentQueries.getGroupByName(pm, group_name);
                    if (group == null) {
                        System.out.println("Creating Group " + group_name);

                        group = new Group(group_name, group_description); // creates transient Group

                        StringTokenizer st = new StringTokenizer(group_schedule, listSplitBy);
                        while (st.hasMoreTokens()) {
                            Schedule schedule = ContentQueries.getScheduleByName(pm, st.nextToken());
                            System.out.println(schedule);
                            group.getSchedules().add(schedule);
                        }
                        pm.makePersistent(group);
                    }
                    System.out.println("Searching Person");
                    Person person = ContentQueries.getPersonByUserName(pm, user_name);
                    if (person == null) {
                        System.out.println("Creating Person " + user_name);
                        counter1++;
                        person = new Person(first_name, last_name, user_name);
                        pm.makePersistent(person);
                    }
                    group.getSubscribers().add(person);
                    System.out.println("Searching Device");
                    Device device = ContentQueries.getDeviceByAddress(pm, device_address);
                    if (device == null) {
                        System.out.println("Creating Device" + device_address);
                        device = new Device(device_type, device_address);
                        pm.makePersistent(device);
                        person.getDevices().add(device);
                        //pm.makePersistent(person);
                    }
                    System.out.println(person);
                    System.out.println(device);
                    System.out.println(group);

                    tx.commit();

                }                
                
                if (recipientCat.equals("DEVICE")) {
                	System.out.println("Line with DEVICE");
                    String subTarget_name = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    String group_description = tokenizer.nextToken();
                    skip = tokenizer.nextToken();   // Member Srquence
                    skip = tokenizer.nextToken();   // Recipient Cat
                    skip = tokenizer.nextToken();   // 
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    skip = tokenizer.nextToken();
                    String user_name = tokenizer.nextToken();
                    String first_name = tokenizer.nextToken();
                    String last_name = tokenizer.nextToken();
                    String device_type = tokenizer.nextToken();
                    String device_address = tokenizer.nextToken();
                    System.out.println(subTarget_name);
                    System.out.println(group_description);
                    System.out.println(user_name);
                    System.out.println(first_name);
                    System.out.println(last_name);
                    System.out.println(device_type);
                    System.out.println(device_address);

                    tx.begin();
                    System.out.println("Searching Group");
                    Group group = ContentQueries.getGroupByName(pm, group_name);
                    if (group == null) {
                        System.out.println("Creating Group " + group_name);

                        group = new Group(group_name, group_description); // creates transient Group

                        StringTokenizer st = new StringTokenizer(group_schedule, listSplitBy);
                        while (st.hasMoreTokens()) {
                            Schedule schedule = ContentQueries.getScheduleByName(pm, st.nextToken());
                            System.out.println(schedule);
                            group.getSchedules().add(schedule);
                        }
                        pm.makePersistent(group);
                    }
                    System.out.println("Searching Person");
                    Person person = ContentQueries.getPersonByUserName(pm, user_name);
                    if (person == null) {
                        System.out.println("Creating Person " + user_name);
                        counter1++;
                        person = new Person(first_name, last_name, user_name);
                        pm.makePersistent(person);
                    }
                    group.getSubscribers().add(person);
                    System.out.println("Searching Device");
                    Device device = ContentQueries.getDeviceByAddress(pm, device_address);
                    if (device == null) {
                        System.out.println("Creating Device" + device_address);
                        device = new Device(device_type, device_address);
                        pm.makePersistent(device);
                        person.getDevices().add(device);
                        //pm.makePersistent(person);
                    }
                    System.out.println(person);
                    System.out.println(device);
                    System.out.println(group);

                    tx.commit();                    
                    
                }

/*                
                if ( recipientCat.equals("GROUP")) {
                }

                if ( recipientCat.equals("DEVICE")) {

                }
*/
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        System.out.println("Counter1=" + counter1 + " Counter2=" + counter2 + " Counter3=" + counter3 + " Counter4=" + counter4);
        
        
        tx.begin();

        Person oliver = ContentQueries.getPersonByUserName(pm, "HKJHW");
        if (oliver != null) {
            System.out.println(oliver);

            for (Device d : oliver.getDevices()) {
                System.out.println(d.getAddress());
            }
        }
        
        Group dsm = ContentQueries.getGroupByName(pm, "SCANAPP-M");
        if (dsm != null) {
        	System.out.println(dsm);
        	
        	for (Subscriber s : dsm.getSubscribers() ) {
        		System.out.println(s);
        		if ( s instanceof Person ) {
        			Person ps = (Person) s;
        			for ( Device ds : ps.getDevices() ) {
        				System.out.println(ds);
        			}
        		}
        	}
        }

        // System.out.println("======================= TEST =============================");
        ContentQueries.getGroups(pm);
        tx.commit();
        
        pmf.close();

    }

}
