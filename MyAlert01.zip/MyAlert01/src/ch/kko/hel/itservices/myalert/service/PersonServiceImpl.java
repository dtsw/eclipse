package ch.kko.hel.itservices.myalert.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.kko.hel.itservices.myalert.dao.GroupDao;
import ch.kko.hel.itservices.myalert.dao.PersonDao;
import ch.kko.hel.itservices.myalert.dto.PersonDto;
import ch.kko.hel.itservices.myalert.entity.Person;
import ch.kko.hel.itservices.myalert.mapper.PersonMapper;

@Service
public class PersonServiceImpl implements PersonService {
	
	@Autowired
	private PersonDao personDao;

	@Autowired
	private PersonMapper personMapper;
	
	public List<PersonDto> findAll() {

		List<Person> persons = personDao.getAll();
		List<PersonDto> personDtos = new ArrayList<PersonDto>();
		for(Person person : persons) {
			personDtos.add(personMapper.mapEntityToDto(person));
		}
		return personDtos;

	}

}
