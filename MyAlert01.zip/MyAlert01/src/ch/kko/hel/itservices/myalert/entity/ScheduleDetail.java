package ch.kko.hel.itservices.myalert.entity;

import java.util.HashSet;
import java.util.Set;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

/**
 * Definition of a ScheduleDetail
 * Represents a Time Schedule, and contains day from to etc.
 */
@PersistenceCapable
public class ScheduleDetail
{
    public static final boolean FULL_DAY = true;
    public static final boolean PART_DAY = false;

    @PrimaryKey
    @Persistent(valueStrategy=IdGeneratorStrategy.NATIVE)
    protected Integer id;
    protected String name;
    protected int startDay;
    protected int endDay;
    protected boolean fullDay;
    protected int startHour;
    protected int endHour;
    
    public ScheduleDetail(String name)
    {
    	this.name = name;
    }

    public ScheduleDetail(int startDay, int endDay, boolean fullDay, int startHour, int endHour) {
    	this.startDay = startDay;
    	this.endDay = endDay;
    	this.fullDay = fullDay;
    	this.startHour = startHour;
    	this.endHour = endHour;
    }

    public ScheduleDetail(int startDay, int endDay, boolean fullDay) {
        this.startDay = startDay;
        this.endDay = endDay;
        this.fullDay = fullDay;
    }

    public Integer getId()
    {
        return id;
    }
    
	public void setId(Integer id) {
		this.id = id;
	}

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStartDay() {
		return startDay;
	}

	public void setStartDay(int startDay) {
		this.startDay = startDay;
	}

	public int getEndDay() {
		return endDay;
	}

	public void setEndDay(int endDay) {
		this.endDay = endDay;
	}

	public boolean isFullDay() {
		return fullDay;
	}

	public void setFullDay(boolean fullDay) {
		this.fullDay = fullDay;
	}

	public int getStartHour() {
		return startHour;
	}

	public void setStartHour(int startHour) {
		this.startHour = startHour;
	}

	public int getEndHour() {
		return endHour;
	}

	public void setEndHour(int endHour) {
		this.endHour = endHour;
	}

	public String toString()
    {
        return "ScheduleDetail : " + id + " Name: " + name;
    }
}