package ch.kko.hel.itservices.myalert.entity;

import javax.jdo.annotations.PersistenceCapable;

/**
 * Definition of a Book. Extends basic Product class.
 */
@PersistenceCapable
public class Device extends Subscriber {
	protected String type = null;
	protected String address = null;

	public Device() {
		super("DEVICE");
	}
	
	public Device(String type, String address) {
		super("DEVICE");
		this.type = type;
		this.address = address;
	}

	public String toString() {
		return "Device : " + type + " - " + address;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
}