package ch.kko.hel.itservices.myalert.entity;

import java.util.HashSet;
import java.util.Set;

import javax.jdo.annotations.*;

@PersistenceCapable
public class Group
{
    @PrimaryKey
    @Persistent(valueStrategy=IdGeneratorStrategy.NATIVE)
	Integer id;
	String name = null;
	String description = "";
    Set<Subscriber> subscribers = new HashSet<>();
    Set<Schedule> schedules = new HashSet<>();

    public Group() {}
    
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Group(String name)
    {
        this.name = name;
    }
    
    public Group(String name, String description)
    {
        this.name = name;
        this.description = description;
    }
    
    public String getName() {
    	return name;
    }

    public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<Subscriber> getSubscribers() {return subscribers;}
	public void setSubscribers(Set<Subscriber> subscribers) {this.subscribers = subscribers;}

	public Set<Schedule> getSchedules() {return schedules;}
	public void setSchedules(Set<Schedule> schedules) {this.schedules = schedules;}

}
