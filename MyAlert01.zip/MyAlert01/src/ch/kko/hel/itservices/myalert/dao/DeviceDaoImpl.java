package ch.kko.hel.itservices.myalert.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.Extent;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ch.kko.hel.itservices.myalert.MyAlertPersistenceManager;
import ch.kko.hel.itservices.myalert.entity.Device;
import ch.kko.hel.itservices.myalert.mapper.DeviceMapper;

@Repository
public class DeviceDaoImpl implements DeviceDao {

	@Autowired
	private DeviceMapper deviceMapper;

	@Autowired
	ServletContext context;

	@Override
	public void insert(Device device) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Device> getAll() {
        PersistenceManagerFactory pmf = (PersistenceManagerFactory) context.getAttribute("pmf");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx=pm.currentTransaction();
        tx.begin();
        Extent<Device> e2 = pm.getExtent(Device.class, true);
		List<Device> devices = new ArrayList<Device>();
		Iterator<Device> iter2 = e2.iterator();
		while (iter2.hasNext()) {
			Object obj = iter2.next();
			Device g = (Device) obj;
        	devices.add(g);
		}
		tx.commit();
		return devices;
	}

	@Override
	public Device getById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Device device) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(Device device) {
		// TODO Auto-generated method stub

	}

}
