package ch.kko.hel.itservices.myalert.mapper;

import org.springframework.stereotype.Component;

import ch.kko.hel.itservices.myalert.dto.PersonDto;
import ch.kko.hel.itservices.myalert.entity.Person;

@Component
public class PersonMapper {
	public Person mapDtoToEntity(PersonDto personDto) {
		Person person = new Person();
		if(null != personDto.getId()) person.setId(personDto.getId());
		if(null != personDto.getFirstname()) person.setFirstname(personDto.getFirstname());
		if(null != personDto.getLastname()) person.setLastname(personDto.getLastname());
		if(null != personDto.getUsername()) person.setUsername(personDto.getUsername());
		return person;
	}
	
	public PersonDto mapEntityToDto(Person person) {
		PersonDto PersonDto = new PersonDto();
		if(null != person.getId()) PersonDto.setId(person.getId());
		if(null != person.getFirstname()) PersonDto.setFirstname(person.getFirstname());
		if(null != person.getLastname()) PersonDto.setLastname(person.getLastname());
		if(null != person.getUsername()) PersonDto.setUsername(person.getUsername());
		return PersonDto;
	}
}
