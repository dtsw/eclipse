package ch.kko.hel.itservices.myalert.repository;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Group;
import ch.kko.hel.itservices.myalert.entity.Subscriber;

public interface GroupRepository {

	public Group save(Group group);

	public Group update(Group group);

	public void delete(Long groupId);

	public List<Group> findAll();

	public Group findById(Long groupId);	

	public Subscriber addPerson(Long groupId, Long personId);
	
	public Subscriber removePerson(Long groupId, Long personId);
	
	public Subscriber addDevice(Long groupId, Long deviceId);
	
	public Subscriber removeDevice(Long groupId, Long deviceId);
	
}
