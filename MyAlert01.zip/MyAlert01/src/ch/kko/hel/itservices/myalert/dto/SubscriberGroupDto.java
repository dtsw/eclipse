package ch.kko.hel.itservices.myalert.dto;

public class SubscriberGroupDto {
	private SubscriberDto subscriberDto;
	private GroupDto groupDto;
	
	public SubscriberDto getSubscriberDto() {
		return subscriberDto;
	}
	public void setSubscriberDto(SubscriberDto subscriberDto) {
		this.subscriberDto = subscriberDto;
	}
	public GroupDto getGroupDto() {
		return groupDto;
	}
	public void setGroupDto(GroupDto groupDto) {
		this.groupDto = groupDto;
	}
}
