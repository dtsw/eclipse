package ch.kko.hel.itservices.myalert.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.kko.hel.itservices.myalert.dao.GroupDao;
import ch.kko.hel.itservices.myalert.entity.Group;

@Service
public class GroupServiceImpl2 implements GroupService2 {
	
	@Autowired
	private GroupDao groupDao;

	public List<Group> findAll() {
		List<Group> groups = groupDao.getAll();
		return groups;
	}

	@Override
	public Group findById(Integer groupid) {
		Group group = groupDao.getById(groupid);
		return group;
	}

	@Override
	public Group findByName(String groupname) {
		Group group = groupDao.getByName(groupname);
		return group;
	}

	@Override
	public void create(Group group) {
		groupDao.insert(group);		
	}

	@Override
	public void remove(Integer id) {
		Group group = groupDao.getById(id);
		groupDao.delete(group);
	}

	@Override
	public void edit(Group group) {
		Group groupCurrent = groupDao.getById(group.getId());
		Group groupToBeEdited = group;
		groupToBeEdited.setSubscribers(groupCurrent.getSubscribers());
		groupDao.update(groupToBeEdited);
	}

}
