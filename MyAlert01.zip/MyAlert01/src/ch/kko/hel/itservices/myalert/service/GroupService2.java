package ch.kko.hel.itservices.myalert.service;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Group;

public interface GroupService2 {
	
	public Group findByName(String name);

	public void create(Group group) ;
	public List<Group> findAll();
	public Group findById(Integer id);
	public void remove(Integer id);
	public void edit(Group group);
	
}
