package ch.kko.hel.itservices.myalert.dao;

import java.util.List;

import ch.kko.hel.itservices.myalert.entity.Device;

public interface DevicePersonDao {
	public List<Device> getAll();
	public List<Device> isPresent(Integer deviceId, Integer personId);

}
