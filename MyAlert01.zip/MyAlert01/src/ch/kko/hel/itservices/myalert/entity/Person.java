package ch.kko.hel.itservices.myalert.entity;

import java.util.HashSet;
import java.util.Set;

import javax.jdo.annotations.PersistenceCapable;

/**
 * Definition of a Book. Extends basic Product class.
 */
@PersistenceCapable
public class Person extends Subscriber {
	protected String firstname = null;
	protected String lastname = null;
	protected String username = null;
	Set<Device> devices = new HashSet<>();

	public Person() {
		super("PERSON");
	}
	
	public Person(String firstname, String lastname, String username) {
		super("PERSON");
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
	}

	public String toString() {
		return "Person : " + username + " - " + firstname + " " + lastname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Set<Device> getDevices() {
		return devices;
	}

	public void setDevices(Set<Device> devices) {
		this.devices = devices;
	}
	
	
}