package ch.kko.hel.itservices.myalert.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.desire3d.examples.jdo.model.ShoppingCart;

import ch.kko.hel.itservices.myalert.PMFConfig;
import ch.kko.hel.itservices.myalert.entity.Device;
import ch.kko.hel.itservices.myalert.entity.Group;
import ch.kko.hel.itservices.myalert.entity.Person;
import ch.kko.hel.itservices.myalert.entity.Subscriber;

@Repository
public class GroupRepositoryImpl implements GroupRepository {

	@Override
	public Group save(Group group) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		pm.makePersistent(group);
		return group;
	}

	@Override
	public Group update(Group group) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Group groupBefore = pm.getObjectById(Group.class, group.getId());
		if(group.getName() != null)
			groupBefore.setName(group.getName());
		if(group.getDescription() != null)
			groupBefore.setDescription(group.getDescription());
		pm.makePersistent(groupBefore);
		return groupBefore;
	}

	@Override
	public List<Group> findAll() {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Query query = pm.newQuery(Group.class);
		List<Group> groups = (List<Group>) query.execute();
		return groups;
	}

	@Override
	public Group findById(Long groupId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Group group = (Group) pm.getObjectById(Group.class, groupId);
		return group;
	}

	@Override
	public void delete(Long groupId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Group group = (Group) pm.getObjectById(Group.class, groupId);
		group.getSchedules().clear();
		group.getSubscribers().clear();
		pm.deletePersistent(group);
	}
	
	@Override
	public Subscriber addPerson(Long groupId, Long personId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Group group = (Group) pm.getObjectById(Group.class, groupId);
		Person s = (Person) pm.getObjectById(Person.class, personId);
		group.getSubscribers().add(s);
		pm.makePersistent(group);
		return s;
	}

	@Override
	public Subscriber removePerson(Long groupId, Long personId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Group group = (Group) pm.getObjectById(Group.class, groupId);
		Person s = (Person) pm.getObjectById(Person.class, personId);
		group.getSubscribers().remove(s);
		pm.makePersistent(group);
		return s;
	}

	@Override
	public Subscriber addDevice(Long groupId, Long deviceId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Group group = (Group) pm.getObjectById(Group.class, groupId);
		Device s = (Device) pm.getObjectById(Device.class, deviceId);
		group.getSubscribers().add(s);
		pm.makePersistent(group);
		return s;
	}
	
	@Override
	public Subscriber removeDevice(Long groupId, Long deviceId) {
		PersistenceManager pm = PMFConfig.getPersistenceManagerFactory().getPersistenceManager();
		Group group = (Group) pm.getObjectById(Group.class, groupId);
		Device s = (Device) pm.getObjectById(Device.class, deviceId);
		group.getSubscribers().remove(s);
		pm.makePersistent(group);
		return s;
	}

}
