package ch.kko.hel.itservices.myalert.entity;

import java.util.HashSet;
import java.util.Set;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

/**
 * Definition of a Schedule
 * Represents a Time Schedule, and contains the key aspects of the item.
 */
@PersistenceCapable
public class Schedule
{
    @PrimaryKey
    @Persistent(valueStrategy=IdGeneratorStrategy.NATIVE)
    protected Integer id;
    protected String name;
    Set<ScheduleDetail> scheduledetails = new HashSet<>();
    
    public Schedule(String name)
    {
    	this.name = name;
    }

    public Integer getId()
    {
        return id;
    }
    
	public void setId(Integer id) {
		this.id = id;
	}

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public Set<ScheduleDetail> getScheduledetails() {
		return scheduledetails;
	}

	public void setScheduledetails(Set<ScheduleDetail> scheduledetails) {
		this.scheduledetails = scheduledetails;
	}

	public String toString()
    {
        return "Schedule : " + id + " Name: " + name;
    }
}