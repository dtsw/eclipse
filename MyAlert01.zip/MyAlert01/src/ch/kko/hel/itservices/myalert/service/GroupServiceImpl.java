package ch.kko.hel.itservices.myalert.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.kko.hel.itservices.myalert.dao.GroupDao;
import ch.kko.hel.itservices.myalert.dto.GroupDto;
import ch.kko.hel.itservices.myalert.entity.Group;
import ch.kko.hel.itservices.myalert.mapper.GroupMapper;

@Service
public class GroupServiceImpl implements GroupService {
	
	@Autowired
	private GroupDao groupDao;

	@Autowired
	private GroupMapper groupMapper;

	public List<GroupDto> findAll() {
		
		List<Group> groups = groupDao.getAll();
		List<GroupDto> groupDtos = new ArrayList<GroupDto>();
		for(Group group : groups) {
			groupDtos.add(groupMapper.mapEntityToDto(group));
		}
		return groupDtos;
		
	}

	@Override
	public GroupDto findById(Integer groupid) {
		Group group = groupDao.getById(groupid);
		if(null != group) {
			return groupMapper.mapEntityToDto(group);
		}
		return null;
	}

	@Override
	public GroupDto findByName(String groupname) {
		Group group = groupDao.getByName(groupname);
		if(null != group) {
			return groupMapper.mapEntityToDto(group);
		}
		return null;
	}

	@Override
	public void create(GroupDto groupDto) {
		groupDao.insert(groupMapper.mapDtoToEntity(groupDto));		
	}

	@Override
	public void remove(Integer id) {
		Group group = groupDao.getById(id);
		groupDao.delete(group);
	}

	@Override
	public void edit(GroupDto groupDto) {
		Group groupCurrent = groupDao.getById(groupDto.getId());
		Group groupToBeEdited = groupMapper.mapDtoToEntity(groupDto);
		groupToBeEdited.setSubscribers(groupCurrent.getSubscribers());
		groupDao.update(groupToBeEdited);
	}

}
