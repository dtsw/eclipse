deviceUpdateMode = false;
groupUpdateMode = false;
personUpdateMode = false;
selectedValue = -1;
groupsData = [];
baseUrl = "/MyAlert01";
	
// Shorthand for $( document ).ready()
$(function() {
    console.log( "ready!" );

	//$( "#groupnumber" ).datepicker();
	$("#removeSubscriberSubmit").on("click", function(e) {
		e.preventDefault();
		$("input[name='subscriber_person']").each( function(e,f) {
			console.log(e,f,f.checked);
			if ( f.checked ) {
				deletePersonGroupObject(f.value, group.id);
			}
		});
		$("input[name='subscriber_device']").each( function(e,f) {
			console.log(e,f,f.checked);
			if ( f.checked ) {
				deleteDeviceGroupObject(f.value, group.id);
			}
		});
	});

    $("#deviceSubmit").on("click", function(e) {
    	e.preventDefault(); 
    	if(deviceUpdateMode){
			updateDevice();
		} else {
			createDevice();
		} 
    });

    $("#groupSubmit").on("click", function(e) {
    	e.preventDefault(); 
    	if(groupUpdateMode) {
			updateGroup();
		} else {
			createGroup();
		}
    });

    $("#personSubmit").on("click", function(e) {
    	e.preventDefault(); 
    	if(personUpdateMode) {
			updatePerson();
		} else {
			createPerson();
		}
    });

    $( "#autocomplete" ).autocomplete({
    	source: [ {"value":1,"label":"C++"}, {"value":2,"label":"Java"}, 
    	{"value":3,"label":"PHP"} ],
    	select: function( event, ui) {
    		event.preventDefault();
    		console.log(ui.item.label);
    		selectedValue = ui.item.value;
    		$( "#autocomplete" ).val(ui.item.label);
    	}
	});

});

function getGroupObject(name) {
	result = {};
	groupsData.forEach(function(a,b) { if ( a.name == name ) result = a; } );
	return result;
}

function methodCall(){

	var clientAccountButtonValue = document.getElementById("subButtonClientAccount").value;
	if(clientAccountButtonValue=="Assign") {
		isPresent();
	}	
	return false;
}

function isPresent(){
	var clientid = $("#clientSelectBox").val();
	var accountid = $("#accountSelectBox").val();
	if(null != clientid && "" != clientid && null!= accountid && "" != accountid) {
		var formData={"clientDto":{"id":clientid},"accountDto":{"id":accountid}};
		$.ajax({
			url : "/Spring-OODD/manytomanybidirectional/clientaccount/isPresent",
			type: "POST",
			data : JSON.stringify(formData),
			beforeSend: function(xhr) {
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json");
			},
			success: function(data, textStatus, jqXHR)
			{
				if(!data) {
					createClientAccount(clientid, accountid);
				} else {
					alert("Client already assigned to this Account");
				}
			},
			error: function (jqXHR, textStatus, errorThrown)
			{				
				alert("Error Status Create:"+errorThrown);
			}
		});		
	}	
	return false;
}

function createClientAccount(clientid,accountid){
	var formData={"clientDto":{"id":clientid},"accountDto":{"id":accountid}};
	$.ajax({
		url : "/Spring-OODD/manytomanybidirectional/clientaccount/create",
		type: "POST",
		data : JSON.stringify(formData),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{				
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Create:"+textStatus);
		}
	});	
	return false;
}

function createGroup(){
	var name = $("#groupInputName").val();
	var description = $("#groupInputDescription").val();
	if(null != name && "" != name) {
		var formData={"name":name,"description":description};
		$.ajax({
			url : "/group/create",
			type: "POST",
			data : JSON.stringify(formData),
			beforeSend: function(xhr) {
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json");
			},
			success: function(data, textStatus, jqXHR)
			{
				document.getElementById("groupInputName").value="";
				document.getElementById("groupInputDescription").value="";				
				loadObjects();
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				document.getElementById("groupInputName").value="";
				document.getElementById("groupInputDescription").value="";				
				alert("Error Status Create:"+textStatus);
			}
		});
	}	
	return false;
}

function createPerson(){
	var firstname = $("#personInputFirstname").val();
	var lastname = $("#personInputLastname").val();
	var username = $("#personInputUsername").val();
	if(null != firstname && "" != firstname && null != lastname && "" != lastname && null != username && "" != username) {
		var formData={"firstname":firstname,"lastname":lastname,"username":username};
		$.ajax({
			url : "/person/create",
			type: "POST",
			data : JSON.stringify(formData),
			beforeSend: function(xhr) {
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json");
			},
			success: function(data, textStatus, jqXHR)
			{
				document.getElementById("personInputFirstname").value="";
				document.getElementById("personInputLastname").value="";
				document.getElementById("personInputUsername").value="";
				loadObjects();
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				document.getElementById("personInputFirstname").value="";
				document.getElementById("personInputLastname").value="";
				document.getElementById("personInputUsername").value="";
				alert("Error Status Create:"+textStatus);
			}
		});
	}	
	return false;
}

function updateClient(){
	var name = $("#clientname").val();
	var id = +$("#clientid").val();
	var formData={"id":id,"name":name};
	$.ajax({
		url : "/Spring-OODD/manytomanybidirectional/client/edit",
		type: "POST",
		data : JSON.stringify(formData),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			document.getElementById("clientname").value="";			
			document.getElementById("subButtonClient").value="Create Client";
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("clientname").value="";
			alert("Error Status Update:"+textStatus);
		}
	});
	return false;
}

function updateAccount(){
	var number = $("#accountnumber").val();
	var id = +$("#accountid").val();
	var formData={"id":id,"number":number};
	$.ajax({
		url : "/Spring-OODD/manytomanybidirectional/account/edit",
		type: "POST",
		data : JSON.stringify(formData),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			document.getElementById("accountnumber").value="";			
			document.getElementById("subButtonAccount").value="Create Account";
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("accountnumber").value="";
			alert("Error Status Update:"+textStatus);
		}
	});
	return false;
}

function editGroupMembers(groupName){
	group = getGroupObject(groupName);
	$("h1#groupTitle").html(group.name);
	dyanamicTableRow = "";
	dyanamicTableRow += "<tr>";
	dyanamicTableRow += "<th></th><th>Name</th><th>Description</th><th>Type</th>";
	dyanamicTableRow += "</tr>"; 
	group.subscribers.forEach(function(a,b) {
		nameLabel = "";
		checkBoxName = "";
		if ( a.type == "PERSON") {
			nameLabel = a.lastname + ", " + a.firstname + " (" + a.username + ")";
			checkBoxName = "subscriber_person";
		}
		if ( a.type == "EMAIL" || a.type == "TEXT_PHONE" ) {
			nameLabel = a.type + ", " + a.address;
			checkBoxName = "subscriber_device";
		}
		dyanamicTableRow += "<tr>";
		dyanamicTableRow += "<td><input type=\"checkbox\" name=\""+checkBoxName+"\" value=\""+a.id+"\"></td>"; 
		dyanamicTableRow += "<td>"+nameLabel+"</td>"; 
		dyanamicTableRow += "<td>"+"</td>"; 
		dyanamicTableRow += "<td>"+a.type+"</td>"; 
		dyanamicTableRow += "</tr>"; 
	});
	$("table#subscriberTable").html(dyanamicTableRow);
}

function loadObjects(){
	
	$.ajax({
		url : baseUrl + "/group/findAll",
		type: "GET",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			//processGroupResponseData(data);
			groupsData = data;
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("groupInputName").value="";
			document.getElementById("groupInputDescription").value="";
			alert("Error Status Load Objects:"+textStatus);
		}
	});

	$.ajax({
		url : baseUrl + "/device/findAll",
		type: "GET",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			processDeviceResponseData(data);
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("deviceInputAddress").value="";
			document.getElementById("deviceSelectType").selectedIndex = 0;
			alert("Error Status Load Objects:"+textStatus);
		}
	});	
	
	$.ajax({
		url : baseUrl + "/person/findAll",
		type: "GET",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			processPersonResponseData(data);
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			document.getElementById("personInputFirstname").value="";
			document.getElementById("personInputLastname").value="";
			document.getElementById("personInputUsername").value="";
			alert("Error Status Load Objects:"+textStatus);
		}
	});
	
	return false;
}
function deleteClientObject(clientid){
	var clientForm={id:clientid};
	delurl="/Spring-OODD/manytomanybidirectional/client/remove/"+clientid;
	$.ajax({
		url : delurl,
		type: "POST",
		data : clientForm,
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}
function deleteAccountObject(accountid){
	var accountForm={id:accountid};
	delurl="/Spring-OODD/manytomanybidirectional/account/remove/"+accountid;
	$.ajax({
		url : delurl,
		type: "POST",
		data : accountForm,
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}
function deletePersonGroupObject(clientid,accountid){
	var formData={"personDto":{"id":clientid},"groupDto":{"id":accountid}};
	delurl=baseUrl+"/group/removePerson";
	$.ajax({
		url : delurl,
		type: "POST",
		data : JSON.stringify(formData),
		dataType: "json",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}
function deleteDeviceGroupObject(clientid,accountid){
	var formData={"deviceDto":{"id":clientid},"groupDto":{"id":accountid}};
	delurl=baseUrl+"/group/removeDevice";
	$.ajax({
		url : delurl,
		type: "POST",
		data : JSON.stringify(formData),
		dataType: "json",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}
function editGroupObject(clientid){
	editurl=baseUrl+"/group/findById/"+clientid;
	var clientForm={};
	$.ajax({
		url : editurl,
		type: "GET",
		data: clientForm,
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			viewGroupObject(data);
			document.getElementById("groupSubmit").value="Update Group";
			groupUpdateMode = true;

		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Find Object:"+textStatus);
		}
	});
}
function editDeviceObject(clientid){
	editurl=baseUrl+"/device/findById/"+clientid;
	var clientForm={id:clientid};
	$.ajax({
		url : editurl,
		type: "GET",
		data : clientForm,
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			viewDeviceObject(data);
			document.getElementById("deviceSubmit").value="Update Device";
			deviceUpdateMode = true;

		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Find Object:"+textStatus);
		}
	});
}
function editAccountObject(accountid){
	editurl="/Spring-OODD/manytomanybidirectional/account/findById/"+accountid;
	var accountForm={id:accountid};
	$.ajax({
		url : editurl,
		type: "GET",
		data : accountForm,
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			viewAccountObject(data);
			document.getElementById("subButtonAccount").value="Update Account";

		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Find Object:"+textStatus);
		}
	});
}

function viewGroupObject(data){
	document.getElementById("groupInputName").value=data.name;
	document.getElementById("groupInputDescription").value=data.description;
	document.getElementById("groupid").value=data.id;
	$.each(data.subscribers, function(itemno, itemvalue) {
		console.log(itemno,itemvalue);
		$.each(itemvalue.devices, function(itemno, itemvalue) {
			console.log(itemno,itemvalue);
		});
	});
}

function viewDeviceObject(data){
	data = { "address": "41797211511", "type": "TEXT_PHONE"};
	document.getElementById("deviceInputAddress").value=data.address;
	document.getElementById("deviceSelectType").value=data.address;
	if(data.type == "TEXT_PHONE") {
		document.getElementById("deviceSelectType").selectedIndex = 1;
	}
	if(data.type == "EMAIL") {
		document.getElementById("deviceSelectType").selectedIndex = 2;
	}
	document.getElementById("deviceid").value=data.id;
}

function viewPersonObject(data){
	document.getElementById("personInputFirstname").value=data.firstname;
	document.getElementById("personInputLastname").value=data.lastname;
	document.getElementById("personInputUsername").value=data.username;
	document.getElementById("personid").value=data.id;
}

function generateDeviceTableData(itemvalue){
	var dataRow="<tr>" +
	"<td>" +itemvalue.type+"</td>"+	
	"<td>" +itemvalue.address+"</td>"+	
	"<td>" +
	"<a href=# onclick=deleteDeviceObject("+itemvalue.id+")>Delete</a>"+
	"&nbsp;|&nbsp;<a href=# onclick=editDeviceObject("+itemvalue.id+")>Edit</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}

function generateGroupTableData(itemvalue){
	var dataRow="<tr>" +
	"<td>" +itemvalue.name+"</td>"+	
	"<td>" +itemvalue.description+"</td>"+	
	"<td>" +
	"<a href=# onclick=deleteGroupObject("+itemvalue.id+")>Delete</a>"+
	"&nbsp;|&nbsp;<a href=# onclick=editGroupObject("+itemvalue.id+")>Edit</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}

function generatePersonTableData(itemvalue){
	var dataRow="<tr>" +
	"<td>" +itemvalue.username+"</td>"+	
	"<td>" +itemvalue.firstname+" "+itemvalue.lastname +"</td>"+	
	"<td>" +
	"<a href=# onclick=deletePersonObject("+itemvalue.id+")>Delete</a>"+
	"&nbsp;|&nbsp;<a href=# onclick=editPersonObject("+itemvalue.id+")>Edit</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}
function generateClientAccountTableData(itemvalue){
	var dataRow="<tr>" +
	"<td>" +itemvalue.clientDto.name+"</td>"+
	"<td>" +itemvalue.accountDto.number+"</td>"+
	"<td>" +
	"<a href=# onclick=deleteClientAccountObject("+itemvalue.clientDto.id+","+itemvalue.accountDto.id+")>Delete</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}

function processDeviceResponseData(responsedata){
	var dyanamicTableRow="<table class=\"table table-bordered\">"+
	"<tr>" +
	"<td>Device Type</td>"+"<td>Device Address</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dynamicDeviceDropdown = "<select id='deviceSelectBox'><option value=''>-- Select Device --</option>";
	
	var dataRow="";
	var dataCombo = "";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generateDeviceTableData(itemvalue);
		dataCombo = dataCombo + "<option value="+itemvalue.id+">"+itemvalue.address+"</option>";
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	dynamicDeviceDropdown = dynamicDeviceDropdown+dataCombo+"</select>";
	document.getElementById("deviceFormResponse").innerHTML=dyanamicTableRow;
	document.getElementById("deviceCombo").innerHTML=dynamicDeviceDropdown;
}

function processGroupResponseData(responsedata){
	var dyanamicTableRow="<table class=\"table table-bordered\">"+
	"<tr>" +
	"<td>Group Name</td>"+"<td>Description</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dynamicGroupDropdown = "<select id='groupSelectBox'><option value=''>-- Select Group --</option>";
	
	var dataRow="";
	var dataCombo = "";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generateGroupTableData(itemvalue);
		dataCombo = dataCombo + "<option value='"+itemvalue.id+"'>"+itemvalue.name+"</option>";
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	dynamicGroupDropdown = dynamicGroupDropdown+dataCombo+"</select>";
	document.getElementById("groupFormResponse").innerHTML=dyanamicTableRow;
	document.getElementById("groupCombo").innerHTML=dynamicGroupDropdown;
}

function processPersonResponseData(responsedata){
	var dyanamicTableRow="<table class=\"table table-bordered\">"+
	"<tr>" +
	"<td>Person Name</td>"+"<td>Username</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dynamicPersonDropdown = "<select id='personSelectBox'><option value=''>-- Select Person --</option>";
	
	var dataRow="";
	var dataCombo = "";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generatePersonTableData(itemvalue);
		dataCombo = dataCombo + "<option value='"+itemvalue.id+"'>"+itemvalue.firstname+" "+itemvalue.lastname+"</option>";
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	dynamicPersonDropdown = dynamicPersonDropdown+dataCombo+"</select>";
	document.getElementById("personFormResponse").innerHTML=dyanamicTableRow;
	document.getElementById("personCombo").innerHTML=dynamicPersonDropdown;
}

function processClientAccountResponseData(responsedata){
	var dyanamicTableRow="<table border=1>"+
	"<tr>" +
	"<td>Client Name</td>"+"<td>Account Name</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dataRow="";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generateClientAccountTableData(itemvalue);
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	document.getElementById("clientAccountFormResponse").innerHTML=dyanamicTableRow;
}