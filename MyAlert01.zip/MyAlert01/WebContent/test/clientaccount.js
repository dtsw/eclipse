deviceUpdateMode = false;
groupUpdateMode = false;
personUpdateMode = false;
selectedValue = -1;
groupData = [];
deviceData = [];
personData = [];
subscriberDatasource = [];
subscriberCurrentType = "";
baseUrl = "/MyAlert01";
	
// Shorthand for $( document ).ready()
$(function() {
    console.log( "ready!" );

	//$( "#groupnumber" ).datepicker();
	$("#removeSubscriberSubmit").on("click", function(e) {
		e.preventDefault();
		$("input[name='subscriber_person']").each( function(e,f) {
			console.log(e,f,f.checked);
			if ( f.checked ) {
				deletePersonGroupObject(f.value, group.id);
			}
		});
		$("input[name='subscriber_device']").each( function(e,f) {
			console.log(e,f,f.checked);
			if ( f.checked ) {
				deleteDeviceGroupObject(f.value, group.id);
			}
		});
	});

	$("#addSubscriberSubmit").on("click", function(e) {
		e.preventDefault();
		id = $("input[name='subscriberSearchInputHidden']").val();
		if ( subscriberCurrentType == "person" ) {
			addPersonGroupObject(id, group.id);
		}
		if ( subscriberCurrentType == "device" ) {
			addDeviceGroupObject(id, group.id);
		}
		
	});

	$("#deviceSubmit").on("click", function(e) {
    	e.preventDefault(); 
    	if(deviceUpdateMode){
			updateDevice();
		} else {
			createDevice();
		} 
    });

    $("#groupSubmit").on("click", function(e) {
    	e.preventDefault(); 
    	if(groupUpdateMode) {
			updateGroup();
		} else {
			createGroup();
		}
    });

    $("#personSubmit").on("click", function(e) {
    	e.preventDefault(); 
    	if(personUpdateMode) {
			updatePerson();
		} else {
			createPerson();
		}
    });

    $( "#subscriberSearchInput" ).autocomplete({
    	source: subscriberDatasource,
    	select: function( event, ui) {
    		console.log(event);
    		console.log(ui);
    		event.preventDefault();
    		console.log(ui.item.label);
    		selectedValue = ui.item.value;
    		$( "#subscriberSearchInput" ).val(ui.item.label);
    		$( "#subscriberSearchInputHidden" ).val(ui.item.value);
    		$( "#subscriberTypeInputHidden").val();
    	}
	});

});

function switchSource(type) {
	subscriberDatasource = [];
	if ( type == "device" ) {
		deviceData.forEach(function(a,b) { subscriberDatasource.push({"value": a.id, "label": a.type + "_" + a.address }); } );	
	}
	if ( type == "person" ) {
		personData.forEach(function(a,b) { subscriberDatasource.push({"value": a.id, "label": a.lastname + ", " + a.firstname + " (" + a.username + ")"}); } );
	}
	subscriberCurrentType = type;
	$( "#subscriberSearchInput" ).autocomplete('option', 'source', subscriberDatasource);
}

function methodCall(){

	var clientAccountButtonValue = document.getElementById("subButtonClientAccount").value;
	if(clientAccountButtonValue=="Assign") {
		isPresent();
	}	
	return false;
}

function isPresent(){
	var clientid = $("#clientSelectBox").val();
	var accountid = $("#accountSelectBox").val();
	if(null != clientid && "" != clientid && null!= accountid && "" != accountid) {
		var formData={"clientDto":{"id":clientid},"accountDto":{"id":accountid}};
		$.ajax({
			url : "/Spring-OODD/manytomanybidirectional/clientaccount/isPresent",
			type: "POST",
			data : JSON.stringify(formData),
			beforeSend: function(xhr) {
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json");
			},
			success: function(data, textStatus, jqXHR)
			{
				if(!data) {
					createClientAccount(clientid, accountid);
				} else {
					alert("Client already assigned to this Account");
				}
			},
			error: function (jqXHR, textStatus, errorThrown)
			{				
				alert("Error Status Create:"+errorThrown);
			}
		});		
	}	
	return false;
}

function createClientAccount(clientid,accountid){
	var formData={"clientDto":{"id":clientid},"accountDto":{"id":accountid}};
	$.ajax({
		url : "/Spring-OODD/manytomanybidirectional/clientaccount/create",
		type: "POST",
		data : JSON.stringify(formData),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{				
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Create:"+textStatus);
		}
	});	
	return false;
}

// ---------------------------------------------------------
// GROUP
// ---------------------------------------------------------
function getGroupObject(id) {
	result = {};
	groupData.forEach(function(a,b) { if ( a.id == id ) result = a; } );
	return result;
}

function createGroup(){
	var name = $("#groupNameInput").val();
	var description = $("#groupDescriptionInput").val();
	if(null != name && "" != name) {
		var formData={"name":name,"description":description};
		$.ajax({
			url : baseUrl + "/group/save",
			type: "POST",
			data : JSON.stringify(formData),
			beforeSend: function(xhr) {
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json");
			},
			success: function(data, textStatus, jqXHR)
			{
				document.getElementById("groupNameInput").value="";
				document.getElementById("groupDescriptionInput").value="";				
				loadObjects();
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				document.getElementById("groupNameInput").value="";
				document.getElementById("groupDescriptionInput").value="";				
				alert("Error Status Create:"+textStatus);
			}
		});
	}	
	return false;
}

function updateGroup(){
	var name = $("#groupNameInput").val();
	var description = $("#groupDescriptionInput").val();
	var id = +$("#groupid").val();
	var formData={"id":id,"name":name,"description":description};
	$.ajax({
		url : baseUrl + "/group/update",
		type: "POST",
		data : JSON.stringify(formData),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			document.getElementById("groupNameInput").value="";
			document.getElementById("groupDescriptionInput").value="";
			document.getElementById("groupSubmit").value="Create Account";
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("groupNameInput").value="";
			document.getElementById("groupDescriptionInput").value="";
			alert("Error Status Update:"+textStatus);
		}
	});
	return false;
}

function editGroupMembers(groupId){
	group = getGroupObject(groupId);
	$("h1#groupTitle").html(group.name);
	dyanamicTableRow = "";
	dyanamicTableRow += "<tr>";
	dyanamicTableRow += "<th></th><th>Name</th><th>Description</th><th>Type</th>";
	dyanamicTableRow += "</tr>"; 
	group.subscribers.forEach(function(a,b) {
		nameLabel = "";
		checkBoxName = "";
		if ( a.type == "PERSON") {
			nameLabel = a.lastname + ", " + a.firstname + " (" + a.username + ")";
			checkBoxName = "subscriber_person";
		}
		if ( a.type == "EMAIL" || a.type == "TEXT_PHONE" ) {
			nameLabel = a.type + ", " + a.address;
			checkBoxName = "subscriber_device";
		}
		dyanamicTableRow += "<tr>";
		dyanamicTableRow += "<td><input type=\"checkbox\" name=\""+checkBoxName+"\" value=\""+a.id+"\"></td>"; 
		dyanamicTableRow += "<td>"+nameLabel+"</td>"; 
		dyanamicTableRow += "<td>"+"</td>"; 
		dyanamicTableRow += "<td>"+a.type+"</td>"; 
		dyanamicTableRow += "</tr>"; 
	});
	$("table#subscriberTable").html(dyanamicTableRow);
}

function deleteGroupObject(groupid){
	var accountForm={id:groupid};
	delurl= baseUrl + "/group/delete/"+groupid;
	$.ajax({
		url : delurl,
		type: "POST",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}

function addPersonGroupObject(clientid,accountid){
	var formData={"personDto":{"id":clientid},"groupDto":{"id":accountid}};
	delurl=baseUrl+"/group/addPerson";
	$.ajax({
		url : delurl,
		type: "POST",
		data : JSON.stringify(formData),
		dataType: "json",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Add: "+textStatus);
		}
	});
}

function deletePersonGroupObject(clientid,accountid){
	var formData={"personDto":{"id":clientid},"groupDto":{"id":accountid}};
	delurl=baseUrl+"/group/removePerson";
	$.ajax({
		url : delurl,
		type: "POST",
		data : JSON.stringify(formData),
		dataType: "json",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}

function addDeviceGroupObject(clientid,accountid){
	var formData={"deviceDto":{"id":clientid},"groupDto":{"id":accountid}};
	delurl=baseUrl+"/group/addDevice";
	$.ajax({
		url : delurl,
		type: "POST",
		data : JSON.stringify(formData),
		dataType: "json",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Add: "+textStatus);
		}
	});
}

function deleteDeviceGroupObject(clientid,accountid){
	var formData={"deviceDto":{"id":clientid},"groupDto":{"id":accountid}};
	delurl=baseUrl+"/group/removeDevice";
	$.ajax({
		url : delurl,
		type: "POST",
		data : JSON.stringify(formData),
		dataType: "json",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}

function editGroupObject(clientid){
	editurl=baseUrl+"/group/findById/"+clientid;
	var clientForm={};
	$.ajax({
		url : editurl,
		type: "GET",
		data: clientForm,
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			viewGroupObject(data);
			document.getElementById("groupSubmit").value="Update Group";
			groupUpdateMode = true;

		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Find Object:"+textStatus);
		}
	});
}

function viewGroupObject(data){
	document.getElementById("groupNameInput").value=data.name;
	document.getElementById("groupDescriptionInput").value=data.description;
	document.getElementById("groupid").value=data.id;
	$.each(data.subscribers, function(itemno, itemvalue) {
		console.log(itemno,itemvalue);
		$.each(itemvalue.devices, function(itemno, itemvalue) {
			console.log(itemno,itemvalue);
		});
	});
}

function generateGroupTableData(itemvalue){
	var dataRow="<tr>" +
	"<td><a href=# onclick=editGroupMembers("+itemvalue.id+")>" +itemvalue.name+"</a></td>"+	
	"<td>" +itemvalue.description+"</td>"+	
	"<td>" +
	"<a href=# onclick=deleteGroupObject("+itemvalue.id+")>Delete</a>"+
	"&nbsp;|&nbsp;<a href=# onclick=editGroupObject("+itemvalue.id+")>Edit</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}

function processGroupResponseData(responsedata){
	var dyanamicTableRow="<table class=\"table table-bordered\">"+
	"<tr>" +
	"<td>Group Name</td>"+"<td>Description</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dynamicGroupDropdown = "<select id='groupSelectBox'><option value=''>-- Select Group --</option>";
	
	var dataRow="";
	var dataCombo = "";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generateGroupTableData(itemvalue);
		dataCombo = dataCombo + "<option value='"+itemvalue.id+"'>"+itemvalue.name+"</option>";
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	dynamicGroupDropdown = dynamicGroupDropdown+dataCombo+"</select>";
	document.getElementById("groupFormResponse").innerHTML=dyanamicTableRow;
	document.getElementById("groupCombo").innerHTML=dynamicGroupDropdown;
}

//---------------------------------------------------------
// PERSON
//---------------------------------------------------------
function createPerson(){
	var firstname = $("#personFirstnameInput").val();
	var lastname = $("#personLastnameInput").val();
	var username = $("#personUsernameInput").val();
	if(null != firstname && "" != firstname && null != lastname && "" != lastname && null != username && "" != username) {
		var formData={"firstname":firstname,"lastname":lastname,"username":username};
		$.ajax({
			url : baseUrl + "/person/save",
			type: "POST",
			data : JSON.stringify(formData),
			beforeSend: function(xhr) {
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json");
			},
			success: function(data, textStatus, jqXHR)
			{
				document.getElementById("personFirstnameInput").value="";
				document.getElementById("personLastnameInput").value="";
				document.getElementById("personUsernameInput").value="";
				loadObjects();
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				document.getElementById("personFirstnameInput").value="";
				document.getElementById("personLastnameInput").value="";
				document.getElementById("personUsernameInput").value="";
				alert("Error Status Create:"+textStatus);
			}
		});
	}	
	return false;
}

function updatePerson(){
	var firstname = $("#personFirstnameInput").val();
	var lastname = $("#personLastnameInput").val();
	var username = $("#personUsernameInput").val();
	var id = +$("#personid").val();
	var formData={"id":id,"firstname":firstname,"lastname":lastname,"username":username};
	$.ajax({
		url : baseUrl + "/person/update",
		type: "POST",
		data : JSON.stringify(formData),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			document.getElementById("personFirstnameInput").value="";
			document.getElementById("personLastnameInput").value="";
			document.getElementById("personUsernameInput").value="";
			document.getElementById("personSubmit").value="Create Client";
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("personFirstnameInput").value="";
			document.getElementById("personLastnameInput").value="";
			document.getElementById("personUsernameInput").value="";
			alert("Error Status Update:"+textStatus);
		}
	});
	return false;
}

function deletePersonObject(clientid){
	var clientForm={id:clientid};
	delurl= baseUrl + "/person/delete/"+clientid;
	$.ajax({
		url : delurl,
		type: "POST",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}

function editPersonObject(accountid){
	editurl= baseUrl + "/person/findById/"+accountid;
	$.ajax({
		url : editurl,
		type: "GET",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			viewPersonObject(data);
			//document.getElementById("subButtonAccount").value="Update Account";
			personUpdateMode = true;

		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Find Object:"+textStatus);
		}
	});
}

function viewPersonObject(data){
	document.getElementById("personFirstnameInput").value=data.firstname;
	document.getElementById("personLastnameInput").value=data.lastname;
	document.getElementById("personUsernameInput").value=data.username;
	document.getElementById("personid").value=data.id;
}

function generatePersonTableData(itemvalue){
	var dataRow="<tr>" +
	"<td>" +itemvalue.username+"</td>"+	
	"<td>" +itemvalue.firstname+" "+itemvalue.lastname +"</td>"+	
	"<td>" +
	"<a href=# onclick=deletePersonObject("+itemvalue.id+")>Delete</a>"+
	"&nbsp;|&nbsp;<a href=# onclick=editPersonObject("+itemvalue.id+")>Edit</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}

function processPersonResponseData(responsedata){
	var dyanamicTableRow="<table class=\"table table-bordered\">"+
	"<tr>" +
	"<td>Person Name</td>"+"<td>Username</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dynamicPersonDropdown = "<select id='personSelectBox'><option value=''>-- Select Person --</option>";
	
	var dataRow="";
	var dataCombo = "";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generatePersonTableData(itemvalue);
		dataCombo = dataCombo + "<option value='"+itemvalue.id+"'>"+itemvalue.firstname+" "+itemvalue.lastname+"</option>";
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	dynamicPersonDropdown = dynamicPersonDropdown+dataCombo+"</select>";
	document.getElementById("personFormResponse").innerHTML=dyanamicTableRow;
	document.getElementById("personCombo").innerHTML=dynamicPersonDropdown;
}

//---------------------------------------------------------
// DEVICE
//---------------------------------------------------------
function createDevice(){
	var type = $("#deviceTypeSelect").val();
	var address = $("#deviceAddressInput").val();
	var id = +$("#deviceid").val();
	var formData={"type":type,"address":address};
	if(null != type && "" != type && null != address && "" != address) {
		var formData={"type":type,"address":address};
		$.ajax({
			url : baseUrl + "/device/save",
			type: "POST",
			data : JSON.stringify(formData),
			beforeSend: function(xhr) {
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json");
			},
			success: function(data, textStatus, jqXHR)
			{
				document.getElementById("deviceAddressInput").value="";
				document.getElementById("deviceTypeSelect").selectedIndex = 0;
				loadObjects();
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				document.getElementById("deviceAddressInput").value="";
				document.getElementById("deviceTypeSelect").selectedIndex = 0;
				alert("Error Status Create: "+textStatus);
			}
		});
	}	
	return false;
}

function updateDevice(){
	var type = $("#deviceTypeSelect").val();
	var address = $("#deviceAddressInput").val();
	var id = +$("#deviceid").val();
	var formData={"id":id,"type":type,"address":address};
	$.ajax({
		url : baseUrl + "/device/update",
		type: "POST",
		data : JSON.stringify(formData),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("Accept", "application/json");
			xhr.setRequestHeader("Content-Type", "application/json");
		},
		success: function(data, textStatus, jqXHR)
		{
			document.getElementById("deviceAddressInput").value="";
			document.getElementById("deviceTypeSelect").selectedIndex = 0;
			document.getElementById("deviceSubmit").value="Create Account";
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("deviceAddressInput").value="";
			document.getElementById("deviceTypeSelect").selectedIndex = 0;
			alert("Error Status Update: "+textStatus);
		}
	});
	return false;
}

function deleteDeviceObject(clientid){
	var clientForm={id:clientid};
	delurl= baseUrl + "/device/delete/"+clientid;
	$.ajax({
		url : delurl,
		type: "POST",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			loadObjects();
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Delete:"+textStatus);
		}
	});
}

function editDeviceObject(clientid){
	editurl=baseUrl+"/device/findById/"+clientid;
	var clientForm={id:clientid};
	$.ajax({
		url : editurl,
		type: "GET",
		data : clientForm,
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			viewDeviceObject(data);
			document.getElementById("deviceSubmit").value="Update Device";
			deviceUpdateMode = true;

		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert("Error Status Find Object:"+textStatus);
		}
	});
}

function viewDeviceObject(data){
	document.getElementById("deviceAddressInput").value=data.address;
	if(data.type == "TEXT_PHONE") {
		document.getElementById("deviceTypeSelect").selectedIndex = 1;
	}
	if(data.type == "EMAIL") {
		document.getElementById("deviceTypeSelect").selectedIndex = 2;
	}
	document.getElementById("deviceid").value=data.id;
}

function generateDeviceTableData(itemvalue){
	var dataRow="<tr>" +
	"<td>" +itemvalue.type+"</td>"+	
	"<td>" +itemvalue.address+"</td>"+	
	"<td>" +
	"<a href=# onclick=deleteDeviceObject("+itemvalue.id+")>Delete</a>"+
	"&nbsp;|&nbsp;<a href=# onclick=editDeviceObject("+itemvalue.id+")>Edit</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}

function processDeviceResponseData(responsedata){
	var dyanamicTableRow="<table class=\"table table-bordered\">"+
	"<tr>" +
	"<td>Device Type</td>"+"<td>Device Address</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dynamicDeviceDropdown = "<select id='deviceSelectBox'><option value=''>-- Select Device --</option>";
	
	var dataRow="";
	var dataCombo = "";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generateDeviceTableData(itemvalue);
		dataCombo = dataCombo + "<option value="+itemvalue.id+">"+itemvalue.address+"</option>";
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	dynamicDeviceDropdown = dynamicDeviceDropdown+dataCombo+"</select>";
	document.getElementById("deviceFormResponse").innerHTML=dyanamicTableRow;
	document.getElementById("deviceCombo").innerHTML=dynamicDeviceDropdown;
}

//---------------------------------------------------------
// ALL
//---------------------------------------------------------
function loadObjects(){
	
	deviceUpdateMode = false;
	groupUpdateMode = false;
	personUpdateMode = false;

	$.ajax({
		url : baseUrl + "/group/findAll",
		type: "GET",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			processGroupResponseData(data);
			groupData = data;
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("groupNameInput").value="";
			document.getElementById("groupDescriptionInput").value="";
			alert("Error Status Load Objects:"+textStatus);
		}
	});

	$.ajax({
		url : baseUrl + "/device/findAll",
		type: "GET",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			processDeviceResponseData(data);
			deviceData = data;
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			document.getElementById("deviceAddressInput").value="";
			document.getElementById("deviceTypeSelect").selectedIndex = 0;
			alert("Error Status Load Objects:"+textStatus);
		}
	});	
	
	$.ajax({
		url : baseUrl + "/person/findAll",
		type: "GET",
		data : {},
		dataType: "json",
		success: function(data, textStatus, jqXHR)
		{
			processPersonResponseData(data);
			personData = data;
			switchSource('person');
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			document.getElementById("personFirstnameInput").value="";
			document.getElementById("personLastnameInput").value="";
			document.getElementById("personUsernameInput").value="";
			alert("Error Status Load Objects:"+textStatus);
		}
	});
	
	return false;
}

//---------------------------------------------------------
// UNUSED
//---------------------------------------------------------
function generateClientAccountTableData(itemvalue){
	var dataRow="<tr>" +
	"<td>" +itemvalue.clientDto.name+"</td>"+
	"<td>" +itemvalue.accountDto.number+"</td>"+
	"<td>" +
	"<a href=# onclick=deleteClientAccountObject("+itemvalue.clientDto.id+","+itemvalue.accountDto.id+")>Delete</a>"+
	"</td>"+
	"</tr>";
	return dataRow;
}

function processClientAccountResponseData(responsedata){
	var dyanamicTableRow="<table border=1>"+
	"<tr>" +
	"<td>Client Name</td>"+"<td>Account Name</td>"+"<td>Actions</td>"+
	"</tr>";
	
	var dataRow="";
	$.each(responsedata, function(itemno, itemvalue){
		dataRow=dataRow+generateClientAccountTableData(itemvalue);
	});
	dyanamicTableRow=dyanamicTableRow+dataRow+"</table>";
	document.getElementById("clientAccountFormResponse").innerHTML=dyanamicTableRow;
}